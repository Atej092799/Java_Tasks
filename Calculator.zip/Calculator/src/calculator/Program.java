package calculator;
import java.util.Scanner;
import calculatorlibrary.Calculator;
public class Program {
	private Scanner sc = new Scanner(System.in);
	private float operator;
	private float answer;
	Calculator calc;
	public Program() {
		this.calc =   new Calculator();
	}
	public float  getInput(String prompt ) {
		System.out.print(prompt);
		return sc.nextFloat();		
	}
	public void displayMenu() {
		System.out.println("Press 1 to add");
		System.out.println("Press 2 to subtract");
		System.out.println("Press 3 to multiply");
		System.out.println("Press 4 to divide");
		this.operator =  getInput("choice: ");
	}
	public void compute() {
		if(this.operator == 1) {
			this.answer = calc.add();
			System.out.println(calc.getNum1()+" + " +calc.getNum2() +" = " +this.answer);
			start();
			
		}
		
		else if(this.operator == 2) {
			this.answer = calc.subtract();
			System.out.println(calc.getNum1()+" - " +calc.getNum2() +" = " +this.answer);
			start();
		}
		
		else if(this.operator == 3) {
			this.answer = calc.multiply();
			System.out.println(calc.getNum1()+" * " +calc.getNum2() +" = " +this.answer);
			start();
		}
		
		else if(this.operator == 4) {
			this.answer = calc.divide();
			System.out.println(calc.getNum1()+" / " +calc.getNum2() +" = " +this.answer);
			start();
		}
		
		else {
		System.out.println("Invalid operator");
		System.exit(0);
		}
	}
	
	public void start() {
		System.out.println("");
		System.out.println("--Calculator Started--");
		System.out.println("");
		calc.setNum1(getInput("Enter num1: "));
		calc.setNum2(getInput("Enter num2: "));
		displayMenu();
		compute();
	}
	
	
}