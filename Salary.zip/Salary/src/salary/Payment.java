/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salary;


public class Payment {
    public String paymentType;
    
    public float getPayment(String paymentType)
    {
        if("with absences".equals(paymentType))
        {
            return 12500-2000;
        }    
        else if ("withovertime".equals(paymentType))
        {
            return 12500 + 1500;
        }
        else{
            return 12500;
        }
}
    }
