/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salary;

/**
 *
 * @author student.admin
 */
public class Salary {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Payment p = new Payment();
        float value = p.getPayment("with absences");
        float b = p.getPayment("withovertime");
        //Salary s = new Salary();
        Salary s = new Salary();
        
        System.out.println(Send(1));
        System.out.println(value);
        System.out.println(b);
        System.out.println(s.People(1));
    }
    
    static int Send(int a)
    {
        if (a==1)
        {
            return 12345;
        }
        else 
        {
            return 00000;
        }
    }
    
    String People(int a)
    {
        if (a==1)
        {
            return "Already Instantiated";
        }
        else if (a==2)
        {
            return "Unistantiated";
        }
        else{
            return "Wrong Turn!!";
        }
    }
    
}
