/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passbyref;
import Classes.Person;

/**
 *
 * @author 1styrGroupB
 */
public class PassbyRef {

    static void updateName (Person person) {
		person.name = "Oddette";
	}

    public static void main(String[] args) {
        Person person = new Person("Johnson");
		
		System.out.println(person.name);
		updateName(person);
		System.out.println(person.name);
    }
}
