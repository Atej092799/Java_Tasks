


package polymorphism;

class Animal{
    public void sound(){
        System.out.println("Animal is making a sound");
    }
}

class Horse extends Animal{
    @Override
    public void sound(){
        System.out.println("Neigh");
    }
}

class cat extends Animal{
    @Override
    public void sound(){
        System.out.println("Moew");
    }
}

class Dog extends Animal{
    @Override
    public void sound(){
        System.out.println("Aw Aw");
    }
}

class snake extends Animal{
    @Override
    public void sound(){
        System.out.println("SSSSS SSSS");
    }
}


/**
 *
 * @author student.admin
 */
public class Polymorphism {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Animal a = new Animal();
        //a.sound();
        Horse h = new Horse();
        //h.sound();
        cat c = new cat();
        //c.sound();
        Dog d = new Dog();
        //d.sound();
        snake s = new snake();
        //s.sound();
        
        printfunction(a);
        printfunction(h);
        printfunction(c);
        printfunction(d);
        printfunction(s);
    }
    public static void printfunction(Animal a){
        if(a instanceof Horse)
        {
            System.out.println("Neigh");
        }
        else if(a instanceof cat)
        {
            System.out.println("Moew");
        }
        else if(a instanceof Dog)
        {
            System.out.println("Aw Aw Aw");
        }
        else if(a instanceof snake)
        {
            System.out.println("SSSSS SSSS");
        }
        else if(a instanceof Animal)
        {
            System.out.println("Animal is making a sound");
        }
        
    }
}
